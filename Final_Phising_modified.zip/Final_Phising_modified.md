```python
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt
from sklearn import preprocessing, svm
import plotly.express as px
from textblob import TextBlob
from urllib.parse import urlparse,urlencode
import ipaddress
import re
from scipy.stats import pearsonr
import seaborn as sn
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier 
from sklearn.ensemble import BaggingClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import GridSearchCV
```

# Dataset overview


```python
data = pd.read_csv("phishing_and_benign_websites.csv")
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>URLs</th>
      <th>Label</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>http://www.wmmayhem.com/</td>
      <td>Benign</td>
    </tr>
    <tr>
      <th>1</th>
      <td>http://www.ballymenaunitedyouthacademy.com/</td>
      <td>Benign</td>
    </tr>
    <tr>
      <th>2</th>
      <td>http://www.brusselsgaybars.com/</td>
      <td>Benign</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.sportsbettingtennis.net/</td>
      <td>Benign</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://www.i29.mobi/</td>
      <td>Benign</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.info() #table is having two columns: URLs and Label. both contains string.
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 695538 entries, 0 to 695537
    Data columns (total 2 columns):
     #   Column  Non-Null Count   Dtype 
    ---  ------  --------------   ----- 
     0   URLs    695538 non-null  object
     1   Label   695538 non-null  object
    dtypes: object(2)
    memory usage: 10.6+ MB
    


```python
data.shape #table is having 695538 rows
```




    (695538, 2)



# Pre-processing


```python
#address based features
# number of dots in url
def getDots(url):
    pos = url.count('.')
    if(pos < 0):
        return 0
    else:
        return pos
# number of hyphen in url
def getHyphen(url):
    pos = url.count('-')
    if(pos < 0):
        return 0
    else:
        return pos
# URL Domain 
def getDomain(url):  
    domain = urlparse(url).netloc
    if re.match(r"^www.",domain):
        domain = domain.replace("www.","")
    return domain

# @ in URL
def AtSign(url):
    if "@" in url:
        have = 1    
    else:
        have = 0    
    return have

 # Length of URL
def getLength(url):
    return len(url)

# Number of  / in URL
def getDepth(url):
    return url.count('/')

#Checking // in URL
def redirection(url):
    return url.count('//')

# HTTPS in domain
def httpDomain(url):
    domain = urlparse(url).netloc
    if 'https' in domain:
        return 1
    else:
        return 0

# shortening
shortening_links = "goo.gl|t.co|twit.ac|tiny.cc|snipurl.com|post.ly|kl.am|wp.me|db.tt|adf.ly|bitly.com|tinyurl.com|bit.ly|is.gd|po.st|bc.vc|u.to|j.mp|cutt.us|v.gd|tr.im|link.zip.net|shorte.st|x.co|ow.ly|url4.eu|ping.fm|just.as|bkite.com|snipr.com|fic.kr|loopt.us|doiop.com|short.ie|rubyurl.com|om.ly|to.ly|bit.do|lnkd.in|qr.ae|q.gs|cur.lv|ity.im|u.bb|yourls.org|prettylinkpro.com|scrnch.me|filoops.info|vzturl.com|qr.net|1url.com|tweez.me"


# TinyURL
def short(url):
    there=re.search(shortening_links,url)
    if there:
        return 1
    else:
        return 0
    
# ps in URL
def ps(url):
    if '-' in urlparse(url).netloc:
        return 1            
    else:
        return 0            
# Length of domain
def domainLength(url):
    domainL = urlparse(url).netloc
    return len(domainL)

# Number of subdomains (Subdomains)
def subdomains(url):
    domain = urlparse(url).netloc
    subdomains = domain.split('.')
    return len(subdomains)-2 if len(subdomains)>2 else len(subdomains)

# Number of queries in the URL (Queries)
def queries(url):
    return len(urlparse(url).query)

# IP in URL
def ipA(url):
    ip = urlparse(url).netloc
    match = re.search(r'^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$', ip)
    return 1 if match else 0

# Existence of 'https' in the URL path (HTTPS)
def https(url):
    return 1 if 'https' in urlparse(url).path else 0

# Existence of suspicious top level domain (TLD)
def suspiciousTLD(url):
    tld = urlparse(url).netloc.split('.')[-1]
    return 1 if tld in ['zip', 'cricket', 'link', 'work', 'party', 'gq', 'kim', 'country', 'science', 'tk'] else 0

# Existence of port number in the URL (Port)
def portNumber(url):
    return 1 if bool(urlparse(url).port) else 0

# Existence of 'double slash' in the URL path (Double Slash)
def doubleSlash(url):
    return 1 if '//' in urlparse(url).path else 0

# Existence of 'www' in the URL subdomain (WWW)
def www(url):
    return 1 if 'www' in urlparse(url).netloc.split('.')[:-2] else 0

# Ratio of digits in the URL (Digit Ratio)
def digitRatio(url):
    digits = sum(c.isdigit() for c in url)
    return digits/len(url) if len(url)>0 else 0
    
```

# Features Extraction


```python
def featureExtraction(url,label):
    features = []
    features.append(url)
    features.append(getDots(url))
    features.append(getHyphen(url))
    features.append(getDomain(url))
    features.append(AtSign(url))
    features.append(getLength(url))
    features.append(getDepth(url))
    features.append(redirection(url))
    features.append(httpDomain(url))
    features.append(short(url))
    features.append(ps(url))
    features.append(domainLength(url))
    features.append(subdomains(url))
    features.append(queries(url))
    features.append(ipA(url))
    features.append(https(url))
    features.append(suspiciousTLD(url))
    features.append(portNumber(url))
    features.append(doubleSlash(url))
    features.append(www(url))
    features.append(digitRatio(url))
    features.append(label)
    return features

```


```python
features_created = []
label = 0

for i in range(0, 695538):
    url = data['URLs'][i]
    label = data['Label'][i]

    features_created.append(featureExtraction(url,label))

```


```python
feature_names = ['URLs', 'Number_of_Dots', 'Number_of_Hyphen', 'Domain_Name', 'Have_@', 'Length_URL', 'Depth_URL','Re_direction', 'https_in_Domain', 'Tiny_URL', 'Prefix_Suffix', 'Length_of_domain', 'Number_of_subdomains', 'Number_of_queries', 'Existence_of_IP_address', 'Existence_of_https_in_URL_path', 'Existence_of_suspicious_TLD', 'Existence_of_port_number', 'Existence_of_double_slash', 'Existence_of_www_in_URL_subdomain', 'Ratio_of_digits', 'Label']

created_data = pd.DataFrame(features_created, columns= feature_names)
created_data.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>URLs</th>
      <th>Number_of_Dots</th>
      <th>Number_of_Hyphen</th>
      <th>Domain_Name</th>
      <th>Have_@</th>
      <th>Length_URL</th>
      <th>Depth_URL</th>
      <th>Re_direction</th>
      <th>https_in_Domain</th>
      <th>Tiny_URL</th>
      <th>...</th>
      <th>Number_of_subdomains</th>
      <th>Number_of_queries</th>
      <th>Existence_of_IP_address</th>
      <th>Existence_of_https_in_URL_path</th>
      <th>Existence_of_suspicious_TLD</th>
      <th>Existence_of_port_number</th>
      <th>Existence_of_double_slash</th>
      <th>Existence_of_www_in_URL_subdomain</th>
      <th>Ratio_of_digits</th>
      <th>Label</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>http://www.wmmayhem.com/</td>
      <td>2</td>
      <td>0</td>
      <td>wmmayhem.com</td>
      <td>0</td>
      <td>24</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0.0</td>
      <td>Benign</td>
    </tr>
    <tr>
      <th>1</th>
      <td>http://www.ballymenaunitedyouthacademy.com/</td>
      <td>2</td>
      <td>0</td>
      <td>ballymenaunitedyouthacademy.com</td>
      <td>0</td>
      <td>43</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0.0</td>
      <td>Benign</td>
    </tr>
    <tr>
      <th>2</th>
      <td>http://www.brusselsgaybars.com/</td>
      <td>2</td>
      <td>0</td>
      <td>brusselsgaybars.com</td>
      <td>0</td>
      <td>31</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0.0</td>
      <td>Benign</td>
    </tr>
    <tr>
      <th>3</th>
      <td>http://www.sportsbettingtennis.net/</td>
      <td>2</td>
      <td>0</td>
      <td>sportsbettingtennis.net</td>
      <td>0</td>
      <td>35</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0.0</td>
      <td>Benign</td>
    </tr>
    <tr>
      <th>4</th>
      <td>http://www.i29.mobi/</td>
      <td>2</td>
      <td>0</td>
      <td>i29.mobi</td>
      <td>0</td>
      <td>20</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0.1</td>
      <td>Benign</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 22 columns</p>
</div>




```python
#converted phising to 1 and benign to 0
# Add a new column named 'Label_bool'
created_data['Label_bool'] = [1 if x =='Phishing' else 0 for x in created_data['Label']]

```

# Quantitative analysis


```python
#mean of Number of Dots
print("Mean for number of dots is:" , round(created_data['Number_of_Dots'].mean(), 2))

#mean of Number of hyphen
print("Mean for number of hyphen is:" , round(created_data['Number_of_Hyphen'].mean(), 2))

#mean of url length
print("Mean for url length is:" , round(created_data['Length_URL'].mean(), 2))

```

    Mean for number of dots is: 2.32
    Mean for number of hyphen is: 1.07
    Mean for url length is: 54.76
    


```python
#median of Number of Dots
print("Median for number of dots is:" , created_data['Number_of_Dots'].median())
#median of Number of hyphen
print("Median for number of hyphen is:" , created_data['Number_of_Hyphen'].median())
#median of url length
print("Median for url length is:" , created_data['Length_URL'].median())
```

    Median for number of dots is: 2.0
    Median for number of hyphen is: 0.0
    Median for url length is: 42.0
    


```python
# Mode of Number of Dots
print("Mode for number of dots is:", str(created_data['Number_of_Dots'].mode()[0]))

# Mode of Number of Hyphen
print("Mode for number of hyphen is:", str(created_data['Number_of_Hyphen'].mode()[0]))

# Mode of URL length
print("Mode for URL length is:", str(created_data['Length_URL'].mode()[0]))

```

    Mode for number of dots is: 2
    Mode for number of hyphen is: 0
    Mode for URL length is: 31
    


```python
#standard deviation of Number of Dots
print("Standard deviation for number of dots is:" , round(created_data['Number_of_Dots'].std(), 2))
#standard deviation of Number of hyphen
print("Standard deviation for number of hyphen is:" , round(created_data['Number_of_Hyphen'].std(), 2))
#standard deviation of url length
print("Standard deviation for url length is:" , round(created_data['Length_URL'].std(), 2))

```

    Standard deviation for number of dots is: 1.75
    Standard deviation for number of hyphen is: 2.32
    Standard deviation for url length is: 50.47
    


```python
data = created_data['Number_of_Dots']
IQ1 = np.percentile(data, 25)
IQ3 = np.percentile(data, 75)
IQRange = IQ3 - IQ1
  
print("Inter Quartile Range for Number of Dots: " , IQRange)
```

    Inter Quartile Range for Number of Dots:  2.0
    


```python
data = created_data['Number_of_Hyphen']
IQ1 = np.percentile(data, 25)
IQ3 = np.percentile(data, 75)
IQRange = IQ3 - IQ1
  
print("Inter Quartile Range for Number of Hyphen: " , IQRange)

```

    Inter Quartile Range for Number of Hyphen:  1.0
    


```python
data = created_data['Length_URL']
IQ1 = np.percentile(data, 25)
IQ3 = np.percentile(data, 75)
IQRange = IQ3 - IQ1
  
print("Inter Quartile Range for Url Length: " , IQRange)
```

    Inter Quartile Range for Url Length:  33.0
    


```python
list1 = created_data['Length_URL']
list2 = created_data['Label_bool']
 
# Apply the pearsonr()
corr, _ = pearsonr(list1, list2)
print('Pearson correlation between Url Length and likelihood of phishing: %.3f' % corr)
```

    Pearson correlation between Url Length and likelihood of phishing: 0.254
    


```python
list1 = created_data['Number_of_Dots']
list2 = created_data['Label_bool']
 
# Apply the pearsonr()
corr, _ = pearsonr(list1, list2)
print('Pearson correlation between number of dots and likelihood of phishing: %.3f' %  corr)
```

    Pearson correlation between number of dots and likelihood of phishing: 0.323
    


```python
list1 = created_data['Number_of_Hyphen']
list2 = created_data['Label_bool']
 
# Apply the pearsonr()
corr, _ = pearsonr(list1, list2)
print('Pearson correlation between number of hyphens and likelihood of phishing:%.3f' %corr)
```

    Pearson correlation between number of hyphens and likelihood of phishing:-0.098
    

# Data-Visualization


```python
#scatter plot to show the relation between number of dots and number of hyphen with url length
created_data.plot(kind = 'scatter', x = 'Number_of_Dots', y = 'Length_URL', color='red')
plt.ylabel('Length of URL')
plt.xlabel('Number of Dots')
created_data.plot(kind = 'scatter', x = 'Number_of_Hyphen', y = 'Length_URL', color= 'green')
plt.ylabel('Length of URL')
plt.xlabel('Number of Hyphens')
plt.show()
fig=plt.gcf()
fig.tight_layout()
```


    
![png](output_25_0.png)
    



    
![png](output_25_1.png)
    



    <Figure size 640x480 with 0 Axes>



```python
# bar graph
Label = created_data['Label']
Url_length = created_data['Length_URL']
  
fig = plt.figure(figsize = (5, 5))
 
# creating the bar plot
plt.bar(Label, Url_length, color ='red', width = 0.1)
plt.xlabel("Label")
plt.ylabel("Length of URL")
```




    Text(0, 0.5, 'Length of URL')




    
![png](output_26_1.png)
    



```python
# box plot between URL length and label
# Removing outliers
data_outlier_removed = created_data[created_data["Length_URL"]<=300]
sn.boxplot(x="Label", y="Length_URL", data=data_outlier_removed)
plt.ylabel('Length of URL')
```




    Text(0, 0.5, 'Length of URL')




    
![png](output_27_1.png)
    



```python
# histogram for URL length
created_data["Length_URL"].plot(kind = 'hist', bins=[50,100,150,200,250,300,350,400,450,500,550,600], edgecolor="red")
plt.xlabel("Length of URL")
```




    Text(0.5, 0, 'Length of URL')




    
![png](output_28_1.png)
    



```python
#pie chart
created_data.groupby(['Label']).sum(numeric_only=True).plot(kind='pie', y='Length_URL', autopct='%1.0f%%')
plt.ylabel('Length of URL')
```




    Text(0, 0.5, 'Length of URL')




    
![png](output_29_1.png)
    



```python
# List of features
feature_cols = ['Number_of_Dots', 'Number_of_Hyphen', 'Ratio_of_digits' , 'Length_of_domain', 'Number_of_subdomains',  'Existence_of_www_in_URL_subdomain'  , 'Depth_URL']
# Groupby label and sum the features
feature_sum = created_data.groupby(['Label'])[feature_cols].sum(numeric_only=True)

# Add missing features with a value of 0
missing_features = set(feature_cols) - set(feature_sum.columns)
for feature in missing_features:
    feature_sum[feature] = 0

# Create pie chart for phishing URLs
plt.figure(figsize=(7, 8))
plt.pie(feature_sum.loc['Phishing'].values, labels=feature_cols, autopct='%1.0f%%')
plt.title("Features used in Phishing URLs")
plt.show()


```


    
![png](output_30_0.png)
    


# Train-test split


```python
X = created_data.drop(['URLs', 'Domain_Name', 'Label', 'Label_bool'], axis = 1)
y = created_data['Label_bool']

# split the train and test dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20,
                                                    random_state=23)
```

# Logistic regression


```python
# LogisticRegression
clf = LogisticRegression(random_state=0, max_iter=2000)
clf.fit(X_train, y_train)
# Prediction
y_pred = clf.predict(X_test)
  
acc = accuracy_score(y_test, y_pred)
print("Logistic Regression model accuracy (in %):", acc*100)
```

    Logistic Regression model accuracy (in %): 75.44713460045432
    

#  Decision tree


```python
decision_tree_classifier= DecisionTreeClassifier(criterion='entropy', random_state=0)  
decision_tree_classifier.fit(X_train, y_train)  
y_pred= decision_tree_classifier.predict(X_test)  
acc = accuracy_score(y_test, y_pred)
print("Decision tree model accuracy (in %):", acc*100)
```

    Decision tree model accuracy (in %): 85.42068033470397
    

# Decision tree with Bagging classifier


```python
# Create a decision tree classifier with the desired hyperparameters
decision_tree_classifier_with_bagging = DecisionTreeClassifier(criterion='entropy', random_state=0)

# Create a BaggingClassifier with the decision tree classifier as the base estimator
bagging_classifier_decision_tree = BaggingClassifier(estimator=decision_tree_classifier_with_bagging, n_estimators=10, random_state=0)

# Fit the BaggingClassifier on the training set
bagging_classifier_decision_tree.fit(X_train, y_train)

# Make predictions on the test set using the BaggingClassifier
y_pred = bagging_classifier_decision_tree.predict(X_test)

# Evaluate the accuracy of the BaggingClassifier
acc = accuracy_score(y_test, y_pred)
print("Bagging + Decision tree model accuracy (in %):", acc*100)

```

    Bagging + Decision tree model accuracy (in %): 85.73841907007504
    

# Random Forest 


```python
# Create a random forest classifier with the desired hyperparameters
random_forest_classifier = RandomForestClassifier(n_estimators=100, criterion='gini', random_state=0)

# Fit the random forest classifier on the training set
random_forest_classifier.fit(X_train, y_train)

# Make predictions on the test set using the random forest classifier
y_pred = random_forest_classifier.predict(X_test)

# Evaluate the accuracy of the random forest classifier
acc = accuracy_score(y_test, y_pred)
print("Random forest model accuracy (in %):", acc*100)

```

    Random forest model accuracy (in %): 86.1122293469822
    

# Random forest with Bagging Classifier


```python
# Create a random forest classifier with the desired hyperparameters
random_forest_classifier_with_bagging = RandomForestClassifier(n_estimators=19, criterion='entropy', random_state=0)

# Create a BaggingClassifier with the random forest classifier as the base estimator
bagging_classifier_random_forest = BaggingClassifier(estimator=random_forest_classifier_with_bagging, n_estimators=10, random_state=0)

# Fit the BaggingClassifier on the training set
bagging_classifier_random_forest.fit(X_train, y_train)

# Make predictions on the test set using the BaggingClassifier
y_pred = bagging_classifier_random_forest.predict(X_test)

# Evaluate the accuracy of the BaggingClassifier
acc = accuracy_score(y_test, y_pred)
print("Bagging + Random forest model accuracy (in %):", acc*100)


```

    Bagging + Random forest model accuracy (in %): 85.91382235385456
    

# MLP(Multi-layered Perceptron) 


```python
# Define the MLPClassifier
mlp = MLPClassifier()

# Define the hyperparameter grid
param_grid = {
    'hidden_layer_sizes': [(10,), (50,), (100,)],
    'activation': ['relu', 'tanh'],
    'solver': ['sgd', 'adam'],
    'alpha': [0.0001, 0.001, 0.01],
    'max_iter': [1000, 5000],
}

# Perform Grid Search to find the best combination of hyperparameters
grid = GridSearchCV(mlp, param_grid, cv=5, n_jobs=-1)
grid.fit(X_train, y_train)

# Print the best hyperparameters
print("Best Hyperparameters:", grid.best_params_)

# Predict the labels of test data using the best estimator
mlp_classifier = grid.best_estimator_
y_pred = mlp_classifier.predict(X_test)

# Calculate accuracy score and confusion matrix
accuracy = accuracy_score(y_test, y_pred)

print("Accuracy: ", accuracy *100)
```

# Phishing Predictor Function


```python
def Phishing_Predictor(url_input, clf, decision_tree_classifier, random_forest_classifier, mlp_classifier , bagging_classifier_decision_tree, bagging_classifier_random_forest):
    features_created = []
    label = 0
    url = url_input.strip()
    features_created.append(featureExtraction(url,label))
    feature_names = ['URLs', 'Number_of_Dots', 'Number_of_Hyphen', 'Domain_Name', 'Have_@', 'Length_URL', 'Depth_URL','Re_direction', 'https_in_Domain', 'Tiny_URL', 'Prefix_Suffix', 'Length_of_domain', 'Number_of_subdomains', 'Number_of_queries', 'Existence_of_IP_address', 'Existence_of_https_in_URL_path', 'Existence_of_suspicious_TLD', 'Existence_of_port_number', 'Existence_of_double_slash', 'Existence_of_www_in_URL_subdomain', 'Ratio_of_digits', 'Label']

    created_data = pd.DataFrame(features_created, columns=feature_names)
    X = created_data.drop(['URLs', 'Domain_Name', 'Label'], axis=1)

    # Predict using logistic regression model
    lr_pred = clf.predict(X)
    # Predict using decision tree model
    dt_pred = decision_tree_classifier.predict(X)
    # Predict using decision tree with bagging
    bdt_pred = bagging_classifier_decision_tree.predict(X)
    # Predict using MLP model
    mlp_pred = mlp_classifier.predict(X_test)
    #predict usning Random Forest with bagging
    brf_pred= bagging_classifier_random_forest.predict(X)
    # Predict using Random Forest Classifier
    rf_pred =  random_forest_classifier.predict(X)

    # Combine predictions using majority voting
    final_pred = int((lr_pred + dt_pred + rf_pred+ mlp_pred + brf_pred + bdt_pred) >= 3)

    if final_pred == 0:
        print("Legitimate URL")
    else:
        print("Phishing URL")

```


```python
Phishing_Predictor("https://www.google.com/",  clf, decision_tree_classifier, random_forest_classifier, mlp_classifier ,bagging_classifier_decision_tree, bagging_classifier_random_forest)

```

    Legitimate URL
    


```python

```
